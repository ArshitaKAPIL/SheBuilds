CREATE TABLE IF NOT EXISTS comments (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  field TEXT,
  body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pins (
  id SERIAL PRIMARY KEY,
  person TEXT NOT NULL,
  title TEXT NOT NULL,
  place TEXT,
  country TEXT NOT NULL,
  lat DOUBLE PRECISION NOT NULL,
  lon DOUBLE PRECISION NOT NULL,
  partner TEXT,
  volunteers INTEGER,
  reached INTEGER,
  result TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS comments_status_idx ON comments (status, created_at DESC);
CREATE INDEX IF NOT EXISTS pins_status_idx ON pins (status, created_at DESC);
